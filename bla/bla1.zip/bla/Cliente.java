HTTP/1.1 301 Moved Permanently
Content-length: 0
Location: https://github.com/thiguetta/ServidorHTTP/blob/master/Cliente.java
