import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.TimeZone;
import java.io.OutputStream;
import java.io.ObjectOutputStream;

public class Y implements Runnable {
	static Scanner entrada;
	static int porta;
	static String endereco;
	static Socket cliente;
	static ServerSocket server;
	static String url;
	static String protocolo;
		
	public Y(Socket cliente2) {
		this.cliente = cliente;
	}

	public static void leEntrada(){
		System.out.println("SERVIDOR =>");

        //entrada de dados
        System.out.println("Digite pasta de arquivos e uma porta. Exemplo: servidor public_html 8080 ");
        entrada = new Scanner(System.in);
       	String teclado = entrada.nextLine();
        		
       	//divide string em endereço e porta
       	String[] pasta = teclado.split(" ");
       	endereco = pasta[0];
       	String porta1 = pasta[1];
       	// coloca porta como inteiro
       	porta = Integer.parseInt(porta1);	
	}
	    
	public static void main(String[] args) throws IOException {
	    leEntrada();
	    
	    /* cria um socket "server" associado a porta escolhida*/ 
	   server = new ServerSocket(porta);
	    
	   while (true) {
			Socket cliente = server.accept();
			new Thread(new Y(cliente)).start();
			 if (cliente.isConnected()) {
				 System.out.println("O computador " + cliente.getInetAddress().getHostAddress()  + " se conectou ao servidor.");
			  }
	   }
	}

	
	public  void run(){ 
		try {
			String metodo = " ";
			//Buffer para ler requisicao input do cliente
			BufferedReader buffer = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
			System.out.println("Requisição: ");
	        //Lê a primeira linha
	        String linha = buffer.readLine();
	        //quebra a string pelo espaço em branco
	        String[] requisicaoHTTP = linha.split(" ");
	        if(requisicaoHTTP.length == 3){
	        	//pega o metodo
		        metodo = requisicaoHTTP[0];
		        //paga o caminho do arquivo
		        //mudar pra pasta[0]
		        url = requisicaoHTTP[1];
		        //pega o protocolo
		        protocolo = requisicaoHTTP[2];
	        }else if(requisicaoHTTP.length == 2){
	        	//pega o metodo
		        metodo = requisicaoHTTP[0];
		        //pega o protocolo
		        protocolo = requisicaoHTTP[1];
	        }
	        
	        //Enquanto a linha não for vazia
	        while (!linha.isEmpty()) {
	        	//imprime a linha
	        	System.out.println(linha);
	        	//lê a proxima linha
            
				linha = buffer.readLine();
				
			 }
	    
	        metodo();
	     
        	buffer.close();
        	cliente.close();
        } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
 
	    
	public static void metodo() throws IOException{
		String nomeArquivo = endereco + url;
		//abre o arquivo pelo caminho
		File arquivo = new File(nomeArquivo);
		
		if(arquivo.isDirectory()){
	          
			OutputStream stream = cliente.getOutputStream();

	            String arquivos[] = arquivo.list();  
	            String mensagem = "Os arquivos do diretório local são: ";
	            stream.write(mensagem.getBytes(Charset.forName("UTF-8")));
	            
	            String espaco = "\n";
	            for(int i = 0; i < arquivos.length; i++){ 
	              
	              System.out.println(arquivos[i]);
	              stream.write(espaco.getBytes(Charset.forName("UTF-8")));
	              stream.write(arquivos[i].getBytes(Charset.forName("UTF-8")));
	              stream.write(espaco.getBytes(Charset.forName("UTF-8")));

	            }  
	            stream.flush();
	    }
		if(arquivo.exists()){
			String mime = Files.probeContentType(arquivo.toPath());
			System.out.println("Content Type: " + mime);
			OutputStream stream = cliente.getOutputStream();
			//OutputStream stream = server.getOutputStream();

			String send = "HTTP/1.1 200 OK\r\nContent-Type: " + mime + "\r\n";
			stream.write(send.getBytes(Charset.forName("UTF-8")));
			//stream.flush();

			FileInputStream fis = new FileInputStream(arquivo);
			BufferedInputStream bis = new BufferedInputStream(fis);

			stream.write(("Content-Length: " + String.valueOf(arquivo.length()) + "\r\n\r\n").getBytes());
			//stream.flush();


			long tam = arquivo.length();
			int valor = 0;
			byte[] contents;
			while (tam > 0) {

				if (tam >= 1) {
					tam = tam - 1;
					valor = 1;
				} else if (tam < 1) {
					valor = (int) tam;
					tam = 0;
				}

				contents = new byte[valor];
				bis.read(contents, 0, valor);
				stream.write(contents);

			}
			stream.flush();
			fis.close();
			bis.close();

		}
		if (!arquivo.exists()) {
			String status = protocolo + " 404 Not Found: O documento requisitado não existe no servidor\r\n";
            arquivo = new File("/404.html");
        }

         
           //status de sucesso - HTTP/1.1 200 OK
    //       String status = protocolo + " 200 OK\r\n";
           //se o arquivo não existe então abrimos o arquivo de erro, e mudamos o status para 404
     
       
     /*      byte[] conteudo = Files.readAllBytes(arquivo.toPath());
        		 
           
           SimpleDateFormat formatador = new SimpleDateFormat("E, dd MMM yyyy hh:mm:ss", Locale.ENGLISH);
           formatador.setTimeZone(TimeZone.getTimeZone("GMT"));
           Date data = new Date(porta, porta, porta);
           //Formata a dara para o padrao
           String dataFormatada = formatador.format(data) + " GMT";
           //cabeçalho padrão da resposta HTTP
           String header = status
                   + "Location: http://localhost:8000/\r\n"
                   + "Date: " + dataFormatada + "\r\n"
                   + "Server: MeuServidor/1.0\r\n"
                   + "Content-Type: text/html\r\n"
                   + "Content-Length: " + conteudo.length + "\r\n"
                   + "Connection: close\r\n"
                   + "\r\n";
           //cria o canal de resposta utilizando o outputStream
           OutputStream resposta = cliente.getOutputStream();
           //escreve o headers em bytes
           resposta.write(header.getBytes());
           //escreve o conteudo em bytes
           resposta.write(conteudo);
           //encerra a resposta
           resposta.flush();
*/
	    
	    }

}
	


